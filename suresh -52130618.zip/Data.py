import pyodbc

# Hardcoded Global variables used connect to DB
server = 'HCL-02-18\SQLEXPRESS'
database = 'Employee_details'
username = 'vyshu'
password = 'Vyshu@123'
cnxn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + password)
cursor = cnxn.cursor()
class Employee_schema:
    def creating_table(self):
           # query=cursor.execute(''' create database Employee_details '''())
            try:
                values=cursor.execute('''select * from Employee_details_table ''')
                query1=cursor.execute(''' use Employee_details''')
                query2=cursor.execute('''create table Employee_details_table(                   
                                         Name varchar(100),
                                         Emp_Id int,
                                         Salary int,
                                         Project varchar(100))
                                    ''')
                cnxn.commit()
            except:
                print("table is already existed")


createobj=Employee_schema()
createobj.creating_table()

